# wordcount

A small program that counts words, packed up to show off **Archive Explorer**.

- `src/` — the C sources
- `assets/` — a logo and an icon
- `vendor/` — a library, as the `.tar.gz` it shipped in (open it!)
- `data/` — a table and some bytes

Everything here was opened in your browser tab, by a page written in wac.
