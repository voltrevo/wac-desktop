<p align="center"><img src="assets/logo.png" alt="wordcount logo" width="240"></p>

# wordcount

A small program that counts words, packed up to show off **Archive Explorer** — every file here
was opened in your browser tab, by a page written in [wac](https://github.com/voltrevo/wac).

## What's inside

| Folder | What it holds | Files |
|:-------|:--------------|------:|
| `src/` | the C sources | 3 |
| `assets/` | a logo and a banner | 2 |
| `vendor/` | a library, as the `.tar.gz` it shipped in | 1 |
| `data/` | a table, a config and some bytes | 3 |

## Building

```sh
make            # builds ./wordcount
./wordcount < README.md
```

The whole program is one loop — see [`src/main.c`](src/main.c):

```c
while (fgets(line, sizeof line, stdin)) {
    words += count_words(line);   /* src/util/strings.c */
    lines++;
}
```

## Roadmap

- [x] count words
- [x] count lines
- [ ] count *characters*, including ~~bytes~~ multi-byte ones
  - and maybe graphemes

> **Note:** the [guide](docs/guide.md) has more, and `data/cities.csv` is there to try the table view.

---

Made with care. Questions? https://example.invalid/wordcount
