#include <stdio.h>
#include "util/strings.h"

/* Count the words on standard input, and say how many there were. */
int main(int argc, char **argv) {
    char line[4096];
    long words = 0, lines = 0;
    while (fgets(line, sizeof line, stdin)) {
        words += count_words(line);
        lines++;
    }
    printf("%ld words on %ld lines\n", words, lines);
    return 0;
}
