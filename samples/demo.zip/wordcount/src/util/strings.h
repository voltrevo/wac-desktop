#pragma once

int count_words(const char *s);
