#include <ctype.h>
#include "strings.h"

int count_words(const char *s) {
    int n = 0, in_word = 0;
    for (; *s; s++) {
        if (isspace((unsigned char)*s)) { in_word = 0; }
        else if (!in_word) { in_word = 1; n++; }
    }
    return n;
}
