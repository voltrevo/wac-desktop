# Guide

Run `make`, then pipe text into `./wordcount`.

Run `make`, then pipe text into `./wordcount`.

Run `make`, then pipe text into `./wordcount`.

Run `make`, then pipe text into `./wordcount`.

Run `make`, then pipe text into `./wordcount`.

Run `make`, then pipe text into `./wordcount`.

Run `make`, then pipe text into `./wordcount`.

Run `make`, then pipe text into `./wordcount`.

Run `make`, then pipe text into `./wordcount`.

Run `make`, then pipe text into `./wordcount`.

Run `make`, then pipe text into `./wordcount`.

Run `make`, then pipe text into `./wordcount`.

Run `make`, then pipe text into `./wordcount`.

Run `make`, then pipe text into `./wordcount`.

Run `make`, then pipe text into `./wordcount`.

Run `make`, then pipe text into `./wordcount`.

Run `make`, then pipe text into `./wordcount`.

Run `make`, then pipe text into `./wordcount`.

Run `make`, then pipe text into `./wordcount`.

Run `make`, then pipe text into `./wordcount`.

Run `make`, then pipe text into `./wordcount`.

Run `make`, then pipe text into `./wordcount`.

Run `make`, then pipe text into `./wordcount`.

Run `make`, then pipe text into `./wordcount`.

Run `make`, then pipe text into `./wordcount`.

Run `make`, then pipe text into `./wordcount`.

Run `make`, then pipe text into `./wordcount`.

Run `make`, then pipe text into `./wordcount`.

Run `make`, then pipe text into `./wordcount`.

Run `make`, then pipe text into `./wordcount`.

