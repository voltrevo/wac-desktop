# Guide

Back to the [README](../README.md).

## Usage

Run `make`, then pipe text into `./wordcount`:

```sh
cat *.md | ./wordcount
```

1. Build it
2. Run it
3. Count things
